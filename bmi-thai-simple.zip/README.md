# BMI Calculator (Thai Ranges)

Single-file static web app. Works offline locally.

## Run on Mac
1. Unzip the file.
2. Double-click **index.html** to open in your browser.

## Deploy
- **Netlify Drop**: upload this ZIP to https://app.netlify.com/drop
- or any static host.

---
Ranges: <18.5, 18.5–22.9, 23–24.9, 25–29.9, ≥30
Packaged: 2025-08-19T12:39:15.956682Z
